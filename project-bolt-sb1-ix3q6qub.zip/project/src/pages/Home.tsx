import React from 'react';
import { SearchBar } from '../components/SearchBar';
import { SortButton } from '../components/SortButton';
import { UserCard } from '../components/UserCard';
import { useUsers } from '../context/UserContext';
import { Loader } from 'lucide-react';

export function Home() {
  const { loading, error, filteredUsers } = useUsers();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader className="animate-spin text-blue-500" size={48} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-red-500 text-xl">{error}</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-4 mb-8 items-start md:items-center justify-between">
        <div className="w-full md:w-96">
          <SearchBar />
        </div>
        <SortButton />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map(user => (
          <UserCard key={user.id} user={user} />
        ))}
      </div>
    </div>
  );
}