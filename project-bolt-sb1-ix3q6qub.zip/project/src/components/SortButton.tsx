import React from 'react';
import { ArrowUpDown } from 'lucide-react';
import { useUsers } from '../context/UserContext';

export function SortButton() {
  const { sortOrder, setSortOrder } = useUsers();

  return (
    <button
      onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
      className="flex items-center gap-2 px-4 py-2 rounded-lg
                bg-blue-500 hover:bg-blue-600 text-white
                transition-colors duration-200"
    >
      <ArrowUpDown size={20} />
      Sort {sortOrder === 'asc' ? 'Z-A' : 'A-Z'}
    </button>
  );
}