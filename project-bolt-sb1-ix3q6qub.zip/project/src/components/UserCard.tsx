import React from 'react';
import { Mail, MapPin } from 'lucide-react';
import { User } from '../types/user';
import { Link } from 'react-router-dom';

type UserCardProps = {
  user: User;
};

export function UserCard({ user }: UserCardProps) {
  return (
    <Link to={`/user/${user.id}`}>
      <div className="p-6 rounded-lg border border-gray-200 dark:border-gray-700
                    bg-white dark:bg-gray-800 shadow-sm hover:shadow-md
                    transition-all duration-200 cursor-pointer">
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          {user.name}
        </h3>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
            <Mail size={18} />
            <span>{user.email}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600 dark:text-gray-300">
            <MapPin size={18} />
            <span>{user.address.city}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}